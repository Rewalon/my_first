package com.example.my_first

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
